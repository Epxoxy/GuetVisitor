﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuetAnalysis.Models
{
    [Serializable]
    [ProtoContract]
    public class SiteModel
    {
        [ProtoMember(1)]
        public string SiteName { get; set; }
        [ProtoMember(2)]
        public string EncodingName { get; set; }
        [ProtoMember(3)]
        public WebPageModel LoginModel { get; set; }
        [ProtoMember(4)]
        public WebPageModel LogoutModel { get; set; }

        public string LoginUrl => LoginModel == null ? null : LoginModel.Url;
        public string LogoutUrl => LogoutModel == null ? null : LogoutModel.Url;

        [ProtoMember(5)]
        public Dictionary<string, string> Patterns { get; set; }
        [ProtoMember(6)]
        public Dictionary<string, WebPageModel> WebPageModels { get; set; }
        //
        [ProtoMember(7)]
        public List<string> MenuKeys { get; internal set; }
        [ProtoMember(8)]
        public List<string> PostKeys { get; internal set; }


        public SiteModel() { }

        public WebPageModel getWebPageModel(string key)
        {
            if (WebPageModels == null || !WebPageModels.ContainsKey(key)) return null;
            return WebPageModels[key];
        }

        public string getPattern(string key)
        {
            if (Patterns == null || !Patterns.ContainsKey(key)) return null;
            return Patterns[key];
        }
    }
}
