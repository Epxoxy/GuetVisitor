﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuetAnalysis.Models
{
    [Serializable]
    [ProtoContract]
    public class WebPageModel
    {
        [ProtoMember(1)]
        public string Key { get; private set; }
        [ProtoMember(2)]
        public string Url { get; private set; }
        [ProtoMember(3)]
        public bool IsPost { get; private set; }
        [ProtoMember(4)]
        public string EncodingName { get; private set; }
        [ProtoMember(5)]
        public string RegexPattern { get; private set; }
        [ProtoMember(6)]
        public string PostDataFormat { get; private set; }
        [ProtoMember(7)]
        public string[] DataHeaders { get; private set; }
        [ProtoMember(8)]
        public Optional<string>[] PostOptionals { get; set; }

        public WebPageModel() { }

        public WebPageModel(string key, string url, bool isPost, string encodingName, string regexPattern, string postDataFormat, string[] dataHeaders)
        {
            this.Key = key;
            this.Url = url;
            this.IsPost = isPost;
            this.EncodingName = encodingName;
            this.RegexPattern = regexPattern;
            this.PostDataFormat = postDataFormat;
            this.DataHeaders = dataHeaders;
        }
    }
}
