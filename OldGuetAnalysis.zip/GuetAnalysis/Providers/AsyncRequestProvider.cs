﻿using GuetAnalysis.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GuetAnalysis
{
    public delegate Task<ReceivedData<string>> HttpRequestTask(HttpRequestConfig config, string url, string data, CancellationToken token);
    public delegate Task<HandResult> HandWebDataTask(WebPageModel page, PassingData passing, ReceivedData<string> data);

    public class AsyncHttpRequestProvider : IDisposable
    {
        #region ------ Properties --------
        
        private CancellationTokenSource cacheCTS;
        private HttpRequestConfig httpConfig;

        private int wrongRetryTimes = 2;
        public int WrongReceiveRetryTimes
        {
            get
            {
                return wrongRetryTimes;
            }
            set
            {
                if(wrongRetryTimes != value && wrongRetryTimes >= 0)
                {
                    wrongRetryTimes = value;
                }
            }
        }

        private int webErrorRetryTimes = 2;
        public int WebErrorRetryTimes
        {
            get
            {
                return webErrorRetryTimes;
            }
            set
            {
                if (webErrorRetryTimes != value && webErrorRetryTimes >= 0)
                {
                    webErrorRetryTimes = value;
                }
            }
        }

        #endregion

        public AsyncHttpRequestProvider()
        {
            this.httpConfig = new HttpRequestConfig();
        }
        
        public AsyncHttpRequestProvider(HttpRequestConfig httpConfig)
        {
            this.httpConfig = httpConfig;
        }
        
        #region --------  Async run http request  --------
        
        private void ensureCancelCTS()
        {
            if (cacheCTS != null && !cacheCTS.IsCancellationRequested && cacheCTS.Token.CanBeCanceled)
            {
                cacheCTS.Cancel();
                cacheCTS.Dispose();
                cacheCTS = null;
            }
        }
        
        public void formatDataRequest(IRequestMonitor monitor, WebPageModel pageModel, HandWebDataTask handTask, object[] addition, params string[] datas)
        {
            formatDataRequest(monitor, pageModel, handTask, addition, RepeatInfo.Once, datas);
        }

        public void formatDataRequest(IRequestMonitor monitor, WebPageModel pageModel, HandWebDataTask handTask, object[] addition, RepeatInfo repeat, params string[] datas)
        {
            string data = string.Empty;
            data = string.Format(pageModel.PostDataFormat, datas);
            request(monitor, pageModel, handTask, repeat, new PassingData() { Data = data, Addition = addition });
        }

        public void request(IRequestMonitor monitor, WebPageModel pageModel, HandWebDataTask handTask, string passingData = null)
        {
            request(monitor, pageModel, handTask, new PassingData() { Data = passingData });
        }

        public void request(IRequestMonitor monitor, WebPageModel pageModel, HandWebDataTask handTask, PassingData data)
        {
            request(monitor, pageModel, handTask, RepeatInfo.Once, data);
        }

        public void request(IRequestMonitor monitor, WebPageModel pageModel, HandWebDataTask handTask, RepeatInfo repeat, string passingData = null)
        {
            request(monitor, pageModel, handTask, repeat, new PassingData() { Data = passingData });
        }

        public void request(IRequestMonitor monitor, WebPageModel pageModel, HandWebDataTask handTask, RepeatInfo repeatInfo, PassingData data)
        {
            if (pageModel == null) return;
            //Cancel Previous
            ensureCancelCTS();
            cacheCTS = new CancellationTokenSource();
            var token = cacheCTS.Token;
            //Create Monitor
            if (monitor == null) monitor = new RequestMonitor();
            //Request
            HttpRequestTask httpRequest;
            if (pageModel.IsPost) httpRequest = NetRequestProvider.HttpPost;
            else httpRequest = NetRequestProvider.HttpGet;
            var requestInfo = new HttpRequestInfo()
            {
                RequestTask = httpRequest,
                HttpRequestConfig = httpConfig,
                RequestMonitor = monitor,
                HandDataTask = handTask,
                Page = pageModel,
                Passing = data,
                RepeatInfo = repeatInfo,
                Token = token
            };
            monitor.IsTaskEmpty = false;
            monitor.IsTaskWaiting = false;
            Task.Run(() => loopingHttpRequest(requestInfo).ContinueWith(task =>
            {
                ensureCancelCTS();
                monitor.IsTaskWaiting = false;
                monitor.IsTaskEmpty = true;
                monitor.IsRequesting = false;
                if (task.IsCanceled)
                {
                    monitor.OnTaskCanceled();
                }
                else if (task.IsFaulted)
                {
                    if (task.Exception.GetBaseException() != null)
                    {
                        monitor.OnFaulted(task.Exception.GetBaseException());
                    }
                }
            }));
        }

        public async Task loopingHttpRequest(HttpRequestInfo info)
        {
            var repeatInfo = info.RepeatInfo;
            var monitor = info.RequestMonitor;
            int repeatTimes = repeatInfo.RepeatTimes;
            int remainTimes = repeatTimes + 1;
            int delayTime = repeatInfo.DelayTime;
            do
            {
                monitor.IsTaskWaiting = false;
                await Task.Run(() => basicHttpRequest(info));

                --remainTimes;
                repeatInfo.RemainTimes = remainTimes;

                monitor.IsTaskWaiting = true;
                await Task.Delay(delayTime, info.Token);

            } while (repeatTimes > 0);
        }

        public async Task basicHttpRequest(HttpRequestInfo info)
        {
            //Jump out for request cancel
            info.Token.ThrowIfCancellationRequested();
            //Monitor
            //Basic data
            WebPageModel page = info.Page;
            ReceivedData<string> received = null;
            var monitor = info.RequestMonitor;
            bool requestResend;
            int wrongDataRetryTimes = WrongReceiveRetryTimes;
            int webErrorRetryTimes = WebErrorRetryTimes;
            do
            {
                //Init
                requestResend = false;
                //Requesting
                monitor.IsRequesting = true;
                try
                {
                    received = await info.RequestTask(info.HttpRequestConfig, page.Url, info.Passing.Data, info.Token);
                }
                catch(AggregateException e)
                {
                    throw;
                }
                catch(WebException e)
                {
                    if (webErrorRetryTimes > 0)
                    {
                        if (e.Response == null) throw;
                        HttpWebResponse response = null;
                        if ((response = (e.Response as HttpWebResponse)) != null)
                        {
                            switch (response.StatusCode)
                            {
                                case HttpStatusCode.NotFound:
                                case HttpStatusCode.InternalServerError:
                                case HttpStatusCode.Forbidden:
                                    throw;
                                default: break;
                            }
                            response.Dispose();
                        }
                        --wrongRetryTimes;
                        requestResend = true;
                        if (monitor.OnRetryRequest(e.Message) == RequestReceipt.Cancel) break;
                    }
                }
                finally
                {
                    monitor.IsRequesting = false;
                }

                //Jump out for request cancel
                info.Token.ThrowIfCancellationRequested();

                //Hand result
                if (!requestResend)
                {
                    if (string.IsNullOrEmpty(received.WebData))
                    {
                        if (wrongDataRetryTimes > 0)
                        {
                            if (monitor.OnRetryRequest(received.ErrorMsg) == RequestReceipt.Cancel) break;
                            --wrongDataRetryTimes;
                            requestResend = true;
                        }
                    }
                    else
                    {
                        HandResult handResult = await info.HandDataTask(page, info.Passing, received);
                        if(handResult == HandResult.RequestResend)
                            requestResend = true;
                    }
                }
            } while (requestResend);
        }

        public async Task<ReceivedData<string>> simpleHttpRuquest(IRequestMonitor monitor, HttpRequestTask httpRequestTask, string url, string data)
        {
            CancellationTokenSource cts = new CancellationTokenSource();
            ReceivedData<string> received = null;
            //Await run try
            if (monitor != null) monitor.IsRequesting = false;
            try
            {
                received = await httpRequestTask(this.httpConfig, url, data, cts.Token);
            }
            catch (AggregateException e)
            {
                throw e;
            }
            finally
            {
                cts.Dispose();
                cts = null;
                if (monitor != null)
                    monitor.IsRequesting = false;
            }
            return received;
        }

        public async Task<ReceivedData<string>> simpleHttpRuquest(HttpRequestTask request, string url, string data, CancellationToken token)
        {
            return await request(this.httpConfig, url, data, token);
        }

        #endregion
        
        public void cancel()
        {
            ensureCancelCTS();
        }

        public void Dispose()
        {
            ensureCancelCTS();
        }

        public class HttpRequestInfo
        {
            public HttpRequestTask RequestTask { get; set; }
            public HttpRequestConfig HttpRequestConfig { get; set; }
            public HandWebDataTask HandDataTask { get; set; }
            public WebPageModel Page { get; set; }
            public PassingData Passing { get; set; }
            public RepeatInfo RepeatInfo { get; set; }
            public CancellationToken Token { get; set; }
            public IRequestMonitor RequestMonitor { get; set; }
        }

        public class RepeatInfo : INotifyPropertyChanged
        {
            public int repeatTimes;
            public int RepeatTimes
            {
                get { return repeatTimes; }
                set
                {
                    if (repeatTimes != value)
                    {
                        repeatTimes = value;
                        RaisePropertyChanged(nameof(RepeatTimes));
                    }
                }
            }

            public int remainTimes;
            public int RemainTimes
            {
                get { return remainTimes; }
                set
                {
                    if (remainTimes != value)
                    {
                        remainTimes = value;
                        RaisePropertyChanged(nameof(RemainTimes));
                    }
                }
            }

            public int delayTime;
            public int DelayTime
            {
                get { return delayTime; }
                set
                {
                    if (delayTime != value)
                    {
                        delayTime = value;
                        RaisePropertyChanged(nameof(DelayTime));
                    }
                }
            }

            public int minDelayTime;
            public int MinDelayTime
            {
                get { return minDelayTime; }
                set
                {
                    if (minDelayTime != value)
                    {
                        minDelayTime = value;
                        RaisePropertyChanged(nameof(MinDelayTime));
                    }
                }
            }

            private RepeatInfo() { }
            public RepeatInfo(int repeatTimes, int delayTime, int minDelayTime)
            {
                this.RepeatTimes = repeatTimes;
                this.DelayTime = delayTime;
                this.MinDelayTime = minDelayTime;
                this.RemainTimes = repeatTimes;
            }

            public static RepeatInfo NewOnce()
            {
                return new RepeatInfo()
                {
                    MinDelayTime = 2000
                };
            }

            public readonly static RepeatInfo Once = new RepeatInfo()
            {
                MinDelayTime = 2000
            };

            public event PropertyChangedEventHandler PropertyChanged;
            public void RaisePropertyChanged(String propertyName)
            {
                this.PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }

    }

    public class AsyncHttpInvoker
    {
        public int MaxCount { get; set; }
        public int Delay { get; set; }
        public bool HasTask { get; internal set; }
        public int TaskInterval { get; set; }

        private static readonly object CreationLock = new object();
        private static AsyncHttpInvoker _instance;
        public static AsyncHttpInvoker Default
        {
            get
            {
                if (_instance == null)
                {
                    lock (CreationLock)
                    {
                        if (_instance == null)
                        {
                            _instance = new AsyncHttpInvoker();
                        }
                    }
                }

                return _instance;
            }
        }

        public void SetRunning()
        {

        }

        public void SetWaiting(int time)
        {

        }

        public void SetComplete()
        {

        }
    }

    public enum RequestReceipt
    {
        Dismiss,
        Cancel,
        OK
    }

    public interface IRequestMonitor
    {
        int Process { get; set; }
        bool IsTaskEmpty { get; set; }
        bool IsRequesting { get; set; }
        bool IsTaskWaiting { get; set; }
        void OnProcessUpdated();
        void OnTaskCanceled();
        RequestReceipt OnRetryRequest(string msg);
        void OnFaulted(Exception e);
    }

    public class RequestMonitor : IRequestMonitor
    {
        public int Process { get; set; }
        public bool IsTaskEmpty { get; set; }
        public bool IsRequesting { get; set; }
        public bool IsTaskWaiting { get; set; }
        public void OnProcessUpdated() { }
        public void OnTaskCanceled() { }
        public void OnRequested(string msg) { }
        public void OnFaulted(Exception e) { }
        public RequestReceipt OnRetryRequest(string msg) { return RequestReceipt.OK; }
    }

}
