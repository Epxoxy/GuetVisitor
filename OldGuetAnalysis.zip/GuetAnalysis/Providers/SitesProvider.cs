﻿using GuetAnalysis.Models;
using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace GuetAnalysis
{
    public class SitesProvider
    {
        private Dictionary<string, SiteModel> siteModels = null;
        private string saveDirectory;
        private string defModelResName;

        #region Constructor

        public SitesProvider(string dictResPath)
        {
            load(dictResPath, false);
        }

        public SitesProvider() : this("GuetAnalysis.Resources.SitesModel.xml")
        {
        }
        
        private void serialize(string path, Dictionary<string, SiteModel> siteModels)
        {
            using (FileStream stream = new FileStream(path, FileMode.OpenOrCreate))
            {
                BinaryFormatter bFormat = new BinaryFormatter();
                bFormat.Serialize(stream, siteModels);
            }
        }

        private void load(string defRes, bool rewrite)
        {
            this.saveDirectory = AppDomain.CurrentDomain.BaseDirectory + "StoredData";
            this.defModelResName = defRes;
            if (!Directory.Exists(saveDirectory))
            {
                try
                {
                    Directory.CreateDirectory(saveDirectory);
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                }
            }
            Dictionary<string, SiteModel> siteModels = null;
            //stopwatch.Start();
            //Deserialize model
            System.Reflection.Assembly asm = System.Reflection.Assembly.GetExecutingAssembly();
            string filePath = saveDirectory + "/Provider.dat";
            if (!rewrite)
            {
                FileInfo file = new FileInfo(filePath);
                if (file.Exists)
                {
                    var stopwatch2 = new System.Diagnostics.Stopwatch();
                    stopwatch2.Start();
                    using (Stream stream = file.Open(FileMode.Open))
                    {
                        if (stream != null)
                        {
                            BinaryFormatter bFormat = new BinaryFormatter();
                            siteModels = (Dictionary<string, SiteModel>)bFormat.Deserialize(stream);
                        }
                    }
                    stopwatch2.Stop();
                    System.Diagnostics.Debug.WriteLine(stopwatch2.ElapsedMilliseconds);
                }
            }
            //Initilize rootDictionary and other option
            if (siteModels == null)
            {
                System.Diagnostics.Debug.WriteLine("Deserialize fail, providerModel == null, use defalut initilize way");
                siteModels = new Dictionary<string, SiteModel>();
                XmlModelLoader loader = new XmlModelLoader(saveDirectory);
                var stopwatch = new Stopwatch();
                stopwatch.Start();
                loader.loadUseLinq(defModelResName, ref siteModels);
                stopwatch.Stop();
                System.Diagnostics.Debug.WriteLine(stopwatch.ElapsedMilliseconds);
                serialize(filePath, siteModels);
            }
            this.siteModels = siteModels;
            //XmlModelLoader.debugOutput(model.SiteModels);
            //stopwatch.Stop();
            //System.Diagnostics.Debug.WriteLine("Used time for create data" + stopwatch.ElapsedMilliseconds);
            
        }

        public void reload()
        {
            load(defModelResName, true);
        }
        
        #endregion

        public SiteModel getSiteModel(string key)
        {
            if (siteModels == null || !siteModels.ContainsKey(key)) return null;
            return siteModels[key];
        }
        
    }
    
    public class DefaultKey
    {
        public const string Login = "Login";
        public const string LoginFail = "LoginFail";
        public const string Title = "Title";
        public const string Option = "Option";
        public const string UnSelectCourse = "UnSelectCourse";
        public const string SelectCourse = "SelectCourse";
        public const string CreditsPoint2 = "CreditsPoint2";
        public const string SelectCourseAction = "SelectCourseAction";
        public const string UnSelectCourseAction = "UnSelectCourseAction";
        public const string Logout = "Logout";
        public const string szhxyGetScore = "szhxyGetScore";
        public const string szhxyCheckLogin = "CheckLogin";
        public const string szhxyLogout = "szhxyLogout";
    }
}
