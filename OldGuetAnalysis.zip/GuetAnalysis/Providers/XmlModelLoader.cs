﻿using GuetAnalysis.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace GuetAnalysis
{
    public class XmlModelLoader
    {
        public XmlModelLoader(string saveDir)
        {
            term = loadTerm(true, 2012, DateTime.Now.Year + 1);
            year = loadYear(true, 2012, DateTime.Now.Year + 1);
            grade = loadGrades(true, 2012, DateTime.Now.Year);
            this.saveDir = saveDir;
        }

        #region Helper data

        public OptionalItem<string>[] loadTerm(bool createEmpty, int beginYear, int endYear)
        {
            List<OptionalItem<string>> xTerm = new List<OptionalItem<string>>();
            if (createEmpty) xTerm.Add(new OptionalItem<string>("Empty", ""));
            for (int i = endYear; i >= beginYear; i--)
            {
                string s = i + "-" + (i + 1);
                xTerm.Add(new OptionalItem<string>(s + "Second Term", s + "_2"));
                xTerm.Add(new OptionalItem<string>(s + "First Term", s + "_1"));
            }
            return xTerm.ToArray();
        }
        
        public OptionalItem<string>[] loadYear(bool createEmpty, int beginYear, int endYear)
        {
            List<OptionalItem<string>> xYear = new List<OptionalItem<string>>();
            if (createEmpty) xYear.Add(new OptionalItem<string>("Empty", ""));
            for (int i = endYear; i >= beginYear; i--)
            {
                string s = i + "-" + (i + 1);
                xYear.Add(new OptionalItem<string>(s + "Year", s));
            }
            return xYear.ToArray();
        }

        private OptionalItem<string>[] loadGrades(bool createEmpty, int fromYear, int toYear)
        {
            List<OptionalItem<string>> grades = new List<OptionalItem<string>>();
            if (createEmpty) grades.Add(new OptionalItem<string>("Empty", ""));
            for (int i = toYear; i >= fromYear; i--)
            {
                string year = i.ToString();
                grades.Add(new OptionalItem<string>(year, year));
            }
            return grades.ToArray();
        }
        
        #endregion

        #region Assignment optionals

        public bool loadOptionalList(string resourcesName, string path, ref OptionalItem<string>[] opList)
        {
            List<OptionalItem<string>> xList = new List<OptionalItem<string>>();
            string content = string.Empty;
            if (!File.Exists(path))
            {
                System.Reflection.Assembly asm = System.Reflection.Assembly.GetExecutingAssembly();
                using (Stream stream = asm.GetManifestResourceStream(resourcesName))
                {
                    using (StreamReader sr = new StreamReader(stream, Encoding.UTF8))
                    {
                        byte[] bytes = UTF8Encoding.UTF8.GetBytes(sr.ReadToEnd());
                        using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
                        {
                            fs.Write(bytes, 0, bytes.Length);
                        }
                    }
                }
            }
            using (FileStream stream = new FileStream(path, FileMode.OpenOrCreate))
            {
                using (StreamReader sr = new StreamReader(stream, Encoding.UTF8))
                {
                    content = sr.ReadToEnd();
                }
            }
            MatchCollection matches = Regex.Matches(content, "<option value=\"(.+?)\">(.+?)</option>");
            foreach (Match match in matches)
            {
                GroupCollection group = match.Groups;
                if (group.Count > 2)
                    xList.Add(new OptionalItem<string>(group[2].Value, group[1].Value));
            }
            if (xList.Count > 0) opList = xList.ToArray();
            return xList.Count > 0;
        }

        public bool updateMajorList(string path)
        {
            if (majorList == null) majorList = new OptionalItem<string>[1];
            return loadOptionalList("GuetAnalysis.Resources.MajorList.txt", path, ref majorList);
        }

        public bool updateClassProperties(string path)
        {
            if (courseProperties == null) courseProperties = new OptionalItem<string>[1];
            return loadOptionalList("GuetAnalysis.Resources.CourseProperties.txt", path, ref courseProperties);
        }

        /// <summary>
        /// Assignment the mulitiple optional array from optionalStringValue
        /// </summary>
        /// <param name="optionalValue">Value the get optional array</param>
        /// <param name="cSplit">Char value to splite string to array</param>
        /// <param name="optionalItems"></param>
        private Optional<string>[] linkMuliOptional(string optionalValue, char cSplit)
        {
            if (string.IsNullOrEmpty(optionalValue)) return null;
            var optionalItems = new List<Optional<string>>();
            string[] array = optionalValue.Split(cSplit);
            foreach (var item in array)
            {
                Optional<string> optionals = new Optional<string>();
                optionals.Items = linkOptional(item);
                optionalItems.Add(optionals);
            }
            return optionalItems.ToArray();
        }

        /// <summary>
        /// Assignment the optional array from optionalStringValue
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        private OptionalItem<string>[] linkOptional(string param)
        {
            if (string.IsNullOrEmpty(param)) return null;
            switch (param)
            {
                case "term": return term;
                case "year": return year;
                case "courseProperties": return courseProperties;
                case "type_exam": return type_examplan;
                case "grade": return grade;
                case "majorList": return majorList;
                case "selecttype": return selectTyle;
                default: return null;
            }
        }

        #endregion
        
        /// <summary>
        ///  Read test only
        /// </summary>
        private bool load(string defResName, string path, ref Dictionary<string, SiteModel> models)
        {
            Dictionary<string, SiteModel> cacheSiteModels = new Dictionary<string, SiteModel>();
            if (majorList == null) updateMajorList(saveDir + "/MajorList.txt");
            if (courseProperties == null) updateClassProperties(saveDir + "/CourseProperties.txt");

            #region Read xml and initalize dictionary
            try
            {
                Stream stream;
                if (!string.IsNullOrEmpty(path) && File.Exists(path))
                {
                    stream = File.Open(path, FileMode.Open);
                }else
                {
                    System.Reflection.Assembly asm = System.Reflection.Assembly.GetExecutingAssembly();
                    stream = asm.GetManifestResourceStream(defResName);
                    StreamReader sr = new StreamReader(stream, Encoding.UTF8);
                    byte[] bytes = UTF8Encoding.UTF8.GetBytes(sr.ReadToEnd());
                    using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
                    {
                        fs.Write(bytes, 0, bytes.Length);
                    }
                    stream.Position = 0;
                }
                using (stream)
                {
                    XmlDocument doc = new XmlDocument();
                    doc.Load(stream);
                    XmlNodeList rootNodeList = doc.SelectSingleNode(Struct.modelsNode).ChildNodes;
                    foreach (XmlNode childNode in rootNodeList)
                    {
                        List<string> cachePostKeys = new List<string>();
                        List<string> cacheMenuKeys = new List<string>();
                        //Get basic attribute of site name and encoding name
                        XmlAttribute siteNameAttribute = childNode.Attributes[Struct.siteNameAttr];
                        XmlAttribute encodingAttribute = childNode.Attributes[Struct.encodingAttr];
                        string siteName = siteNameAttribute == null ? "Common" : siteNameAttribute.Value;
                        string encodingName = encodingAttribute == null ? "utf-8" : encodingAttribute.Value;

                        //Initilize request dictionary
                        Dictionary<string, WebPageModel> webpageModels = new Dictionary<string, WebPageModel>();
                        Dictionary<string, string> patternDictionary = new Dictionary<string, string>();
                        WebPageModel loginModel = null;
                        WebPageModel logoutModel = null;

                        foreach (XmlNode item in childNode.ChildNodes)
                        {
                            if (item.Name == Struct.commentMark) continue;
                            string key = string.Empty;
                            string pattern = string.Empty;
                            if (item.Name == Struct.patternNode)
                            {
                                foreach (XmlAttribute attribute in item.Attributes)
                                {
                                    string value = attribute.Value;
                                    switch (attribute.Name)
                                    {
                                        case Struct.keyAttr: { key = value; } break;
                                        case Struct.patternAttr: { pattern = value; } break;
                                    }
                                }
                                patternDictionary.Add(key, pattern);
                                continue;
                            }
                            //init
                            string itemName = item.Name;
                            string type = string.Empty;
                            string url = string.Empty;
                            string handHeader = string.Empty;
                            string getHandRule = string.Empty;//TODO for page of second action type
                            string postdataFormat = string.Empty;
                            string nextKey = string.Empty;
                            string nomenu = string.Empty;
                            string headersValue = string.Empty;
                            string optionalValue = string.Empty;
                            ////Get and set basic attributes value
                            foreach (XmlAttribute attribute in item.Attributes)
                            {
                                string value = attribute.Value;
                                switch (attribute.Name)
                                {
                                    case Struct.keyAttr: { key = value; } break;
                                    case Struct.typeAttr: { type = value; }break;
                                    case Struct.patternAttr: { pattern = value; } break;
                                    case Struct.urlAttr: { url = value; } break;
                                    case Struct.nextKeyAttr: { nextKey = value; } break;
                                    case Struct.nomenuAttr: { nomenu = value; } break;
                                    case Struct.postdataFormatAttr: { postdataFormat = value; } break;
                                    case Struct.handHeaderAttr: { handHeader = value; } break;
                                    case Struct.getHandRuleAttr: { getHandRule = value; } break;
                                    case Struct.headersAttr: { headersValue = value; } break;
                                    case Struct.optionalAttr: { optionalValue = value; } break;
                                }
                            }
                            System.Diagnostics.Debug.WriteLine(siteName + " -->" + key);
                            //Parse id
                            bool isPost = type == Struct.typePost;
                            //Get headers
                            string[] headers = null;
                            if (!string.IsNullOrEmpty(headersValue)) headers = headersValue.Split('|');
                            ///Create object
                            ///From parameters
                            WebPageModel page = new WebPageModel(key, url, isPost, encodingName, pattern, postdataFormat, headers);
                            //Get if optionals
                            if (!string.IsNullOrEmpty(optionalValue))
                            {
                                page.PostOptionals = linkMuliOptional(optionalValue, '|');
                            }
                            if (!string.IsNullOrEmpty(nextKey))
                            {

                            }
                            //Check for login/logout item
                            if (key == Struct.loginKey)
                            {
                                loginModel = page;
                            }
                            else if (key == Struct.logoutKey)
                            {
                                logoutModel = page;
                            }
                            //Add to dictionary
                            webpageModels.Add(key, page);
                            //Cache post/menu item
                            if (isPost) cachePostKeys.Add(key);
                            if (!string.IsNullOrEmpty(nomenu)) nomenu = string.Empty;
                            else cacheMenuKeys.Add(key);
                        }
                        //Initilize siteModel
                        SiteModel siteModel = new SiteModel()
                        {
                            SiteName = siteName,
                            LoginModel = loginModel,
                            LogoutModel = logoutModel,
                            EncodingName = encodingName,
                            WebPageModels = webpageModels,
                            PostKeys = cachePostKeys,
                            MenuKeys = cacheMenuKeys
                        };
                        if(patternDictionary.Count > 0)
                        {
                            siteModel.Patterns = patternDictionary;
                        }
                        //Add model to dictionary
                        cacheSiteModels.Add(siteName, siteModel);
                    }
                }
                models = cacheSiteModels;
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine("Initialize fail with error (XmlModelLoader.cs, Line:303)\n " + e.Message + e.StackTrace);
                return false;
            }
            return true;
            #endregion
        }

        public bool load(string defResName, ref Dictionary<string, SiteModel> models)
        {
            bool success = load(defResName, saveDir + "/SitesModel.xml", ref models);
            if(!success) return load(defResName, null, ref models);
            return true;
        }

        public bool loadUseLinq(string defResName, ref Dictionary<string, SiteModel> models)
        {
            bool success = loadUseLinq(defResName, saveDir + "/SitesModel.xml", ref models);
            if (!success) return loadUseLinq(defResName, null, ref models);
            return true;
        }

        /// <summary>
        ///  Read test only
        /// </summary>
        private bool loadUseLinq(string defResName, string path, ref Dictionary<string, SiteModel> models)
        {
            Dictionary<string, SiteModel> cacheSiteModels = new Dictionary<string, SiteModel>();
            if (majorList == null) updateMajorList(saveDir + "/MajorList.txt");
            if (courseProperties == null) updateClassProperties(saveDir + "/CourseProperties.txt");

            #region Read xml and initalize dictionary
            try
            {
                Stream stream;
                if (!string.IsNullOrEmpty(path) && File.Exists(path))
                {
                    stream = File.Open(path, FileMode.Open);
                }
                else
                {
                    System.Reflection.Assembly asm = System.Reflection.Assembly.GetExecutingAssembly();
                    stream = asm.GetManifestResourceStream(defResName);
                    StreamReader sr = new StreamReader(stream, Encoding.UTF8);
                    byte[] bytes = UTF8Encoding.UTF8.GetBytes(sr.ReadToEnd());
                    using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
                    {
                        fs.Write(bytes, 0, bytes.Length);
                    }
                    stream.Position = 0;
                }
                using (stream)
                {
                    XElement rootNode = XElement.Load(stream);
                    foreach (var childElement in rootNode.Elements())
                    {
                        List<string> cachePostKeys = new List<string>();
                        List<string> cacheMenuKeys = new List<string>();
                        //Get basic attribute of site name and encoding name
                        var siteNameAttribute = childElement.Attribute(Struct.siteNameAttr);
                        var encodingAttribute = childElement.Attribute(Struct.encodingAttr);
                        string siteName = siteNameAttribute == null ? "Common" : siteNameAttribute.Value;
                        string encodingName = encodingAttribute == null ? "utf-8" : encodingAttribute.Value;

                        //Initilize request dictionary
                        Dictionary<string, WebPageModel> webpageModels = new Dictionary<string, WebPageModel>();
                        Dictionary<string, string> patternDictionary = new Dictionary<string, string>();
                        WebPageModel loginModel = null;
                        WebPageModel logoutModel = null;

                        foreach (var element in childElement.Elements())
                        {
                            if (element.Name.LocalName == Struct.commentMark) continue;
                            string key = string.Empty;
                            string pattern = string.Empty;
                            if (element.Name.LocalName == Struct.patternNode)
                            {
                                foreach (var attribute in element.Attributes())
                                {
                                    string value = attribute.Value;
                                    switch (attribute.Name.LocalName)
                                    {
                                        case Struct.keyAttr: { key = value; } break;
                                        case Struct.patternAttr: { pattern = value; } break;
                                    }
                                }
                                patternDictionary.Add(key, pattern);
                                continue;
                            }
                            //init
                            string itemName = element.Name.LocalName;
                            string type = string.Empty;
                            string url = string.Empty;
                            string handHeader = string.Empty;
                            string getHandRule = string.Empty;//TODO for page of second action type
                            string postdataFormat = string.Empty;
                            string nextKey = string.Empty;
                            string nomenu = string.Empty;
                            string headersValue = string.Empty;
                            string optionalValue = string.Empty;
                            ////Get and set basic attributes value
                            foreach (var attribute in element.Attributes())
                            {
                                string value = attribute.Value;
                                switch (attribute.Name.LocalName)
                                {
                                    case Struct.keyAttr: { key = value; } break;
                                    case Struct.typeAttr: { type = value; } break;
                                    case Struct.patternAttr: { pattern = value; } break;
                                    case Struct.urlAttr: { url = value; } break;
                                    case Struct.nextKeyAttr: { nextKey = value; } break;
                                    case Struct.nomenuAttr: { nomenu = value; } break;
                                    case Struct.postdataFormatAttr: { postdataFormat = value; } break;
                                    case Struct.handHeaderAttr: { handHeader = value; } break;
                                    case Struct.getHandRuleAttr: { getHandRule = value; } break;
                                    case Struct.headersAttr: { headersValue = value; } break;
                                    case Struct.optionalAttr: { optionalValue = value; } break;
                                }
                            }
                            System.Diagnostics.Debug.WriteLine(siteName + " -->" + key);
                            //Parse id
                            bool isPost = type == Struct.typePost;
                            //Get headers
                            string[] headers = null;
                            if (!string.IsNullOrEmpty(headersValue)) headers = headersValue.Split('|');
                            ///Create object
                            ///From parameters
                            WebPageModel page = new WebPageModel(key, url, isPost, encodingName, pattern, postdataFormat, headers);
                            //Get if optionals
                            if (!string.IsNullOrEmpty(optionalValue))
                            {
                                page.PostOptionals = linkMuliOptional(optionalValue, '|');
                            }
                            if (!string.IsNullOrEmpty(nextKey))
                            {

                            }
                            //Check for login/logout item
                            if (key == Struct.loginKey)
                            {
                                loginModel = page;
                            }
                            else if (key == Struct.logoutKey)
                            {
                                logoutModel = page;
                            }
                            //Add to dictionary
                            webpageModels.Add(key, page);
                            //Cache post/menu item
                            if (isPost) cachePostKeys.Add(key);
                            if (!string.IsNullOrEmpty(nomenu)) nomenu = string.Empty;
                            else cacheMenuKeys.Add(key);
                        }
                        //Initilize siteModel
                        SiteModel siteModel = new SiteModel()
                        {
                            SiteName = siteName,
                            LoginModel = loginModel,
                            LogoutModel = logoutModel,
                            EncodingName = encodingName,
                            WebPageModels = webpageModels,
                            PostKeys = cachePostKeys,
                            MenuKeys = cacheMenuKeys
                        };
                        if (patternDictionary.Count > 0)
                        {
                            siteModel.Patterns = patternDictionary;
                        }
                        //Add model to dictionary
                        cacheSiteModels.Add(siteName, siteModel);
                    }
                }
                models = cacheSiteModels;
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine("Initialize fail with error (XmlModelLoader.cs, Line:303)\n " + e.Message + e.StackTrace);
                return false;
            }
            return true;
            #endregion
        }

        /// <summary>
        /// Output dictionary data to console
        /// </summary>
        /// <param name="dict"></param>
        public static string debugOutput(Dictionary<string, SiteModel> models)
        {
            StringBuilder sb = new StringBuilder("ModelDictionary count " + models.Count);

            foreach (var pair in models)
            {
                Dictionary<string, WebPageModel> requestDict = pair.Value.WebPageModels;
                sb.Append(
                    "\nRequestDict count " + requestDict.Count
                    + "\nSite -> " + pair.Key
                    + "\n  Site Name -> " + pair.Value.SiteName
                    + "\n  Encoding  -> " + pair.Value.EncodingName);
                foreach (var item in requestDict)
                {
                    WebPageModel rbm = item.Value;
                    sb.Append(
                          "\n    key -> " + item.Key
                        + "\n      Url -> " + rbm.Url
                        + "\n      RegexPattern -> " + rbm.RegexPattern);

                    string[] headers;
                    if ((headers = rbm.DataHeaders) != null)
                    {
                        sb.Append("\n      DataHeaders");
                        foreach (var header in headers)
                        {
                            sb.Append("\n        > " + header);
                        }
                    }
                    if (!string.IsNullOrEmpty(item.Value.PostDataFormat))
                    {
                        sb.Append("\n      PostDataFormat");
                        sb.Append("\n        > " + item.Value.PostDataFormat);
                    }
                }
            }
            System.Diagnostics.Debug.WriteLine(sb.ToString());
            return sb.ToString();
        }
        
        class Struct
        {
            public const string commentMark = "#comment";
            public const string modelsNode = "models";
            public const string siteNode = "site";
            public const string pageNode = "page";
            public const string patternNode = "pattern";
            public const string siteNameAttr = "siteName";
            public const string encodingAttr = "encoding";
            public const string keyAttr = "key";
            public const string idAttr = "id";
            public const string patternAttr = "pattern";
            public const string typeAttr = "type";
            public const string headersAttr = "headers";
            public const string handHeaderAttr = "handHeader";
            public const string urlAttr = "url";
            public const string nomenuAttr = "nomenu";
            public const string postdataFormatAttr = "postdataFormat";
            public const string nextKeyAttr = "nextKey";
            public const string getHandRuleAttr = "getHandRule";
            public const string optionalAttr = "optional";
            public const string typePost = "post";
            public const string loginKey = "Login";
            public const string logoutKey = "Logout";
        }

        private OptionalItem<string>[] term;
        private OptionalItem<string>[] year;
        private OptionalItem<string>[] grade;
        private OptionalItem<string>[] majorList;
        private OptionalItem<string>[] courseProperties;
        private static OptionalItem<string>[] type_examplan = new OptionalItem<string>[] {
            new OptionalItem<string>("Normal", "0"),
            new OptionalItem<string>("Retake", "1")  };
        private static OptionalItem<string>[] selectTyle = new OptionalItem<string>[] {
            new OptionalItem<string>("Normal", "%d5%fd%b3%a3"),
            new OptionalItem<string>("Retake", "%d6%d8%d0%de")  };
        public string saveDir = string.Empty;
    }
}
