﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GuetAnalysis
{
    public static class RegularEx
    {
        public static MatchCollection rHtml(this String input, string rule)
        {
            if (string.IsNullOrEmpty(input)) return null;
            input = Regex.Replace(input, @"<![\s\S]*?-->", string.Empty);
            input = Regex.Replace(input, @"<script[\s\S]*?script>", string.Empty);
            input = Regex.Replace(input, @"<html[\s\S]*?<body>", string.Empty);
            input = Regex.Replace(input, @">\s+<", "><");
            return input.rHtmlNoReplace(rule);
        }
        public static MatchCollection rHtmlNoReplace(this String input, string rule)
        {
            Regex r = new Regex(rule);
            input = Regex.Replace(input, "\n+\n", " ");
            return r.Matches(input);
        }
        public static MatchCollection rHtmlHead(this String input, string rule)
        {
            input = Regex.Replace(input, @"<![\s\S]*?-->", string.Empty);
            input = Regex.Replace(input, @"<script[\s\S]*?</script>", string.Empty);
            input = Regex.Replace(input, @">\s+<", "><");
            return input.rHtmlNoReplace(rule);
        }
        public static string replaceGtLt(this string input)
        {
            if (string.IsNullOrEmpty(input)) return string.Empty;
            input = Regex.Replace(input, @"<.+?>", "\n");
            input = Regex.Replace(input, @"&nbsp;", string.Empty);
            return input;
        }

        public static DataTable htmlToTable(string tableName, string data, string pattern, string[] headers, int maxMatches)
        {
            //Validate data
            if (string.IsNullOrEmpty(data)) return null;
            if (string.IsNullOrEmpty(pattern)) return null;
            //Match
            MatchCollection matches = data.rHtml(pattern);
            if (matches != null && matches.Count > 0 && matches.Count < maxMatches)
            {
                DataTable dt = new DataTable(tableName);
                //Add headers to datatable
                if (headers != null)
                {
                    for (int m = 0; m < headers.Length; m++)
                    {
                        dt.Columns.Add(headers[m], typeof(string));
                    }
                }
                //Add matches data to datatable
                for (int i = 0; i < matches.Count; i++)
                {
                    GroupCollection group = matches[i].Groups;
                    dt.Rows.Add();
                    for (int j = 1; j < group.Count; j++)
                    {
                        string value = group[j].Value.replaceGtLt();
                        dt.Rows[i][j - 1] = value;
                    }
                }
                //Make every column readOnly
                for (int m = 0; m < dt.Columns.Count; m++)
                {
                    dt.Columns[m].ReadOnly = true;
                }
                return dt;
            }
            else
            {
                return null;
            }
        }
    }
}
