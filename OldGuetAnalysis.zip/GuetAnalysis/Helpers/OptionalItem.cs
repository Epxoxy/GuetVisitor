﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuetAnalysis
{

    [Serializable]
    [ProtoContract]
    public struct OptionalItem<T>
    {
        [ProtoMember(1)]
        public string Display { get; set; }
        [ProtoMember(2)]
        public T Value { get; set; }

        public OptionalItem(string display, T value)
        {
            Display = display;
            Value = value;
        }

        public override string ToString()
        {
            return $"{Display}[{Value}]";
        }
    }

    public enum OptionalType
    {
        Input,
        Selection,
        EditableSelection,
    }

    [Serializable]
    [ProtoContract]
    public struct Optional<T>
    {
        [ProtoMember(1)]
        public string Description { get; set; }
        [ProtoMember(2)]
        public OptionalType Type { get; set; }
        [ProtoMember(3)]
        public OptionalItem<T>[] Items { get; set; }
    }

    public struct SelectableOptionals<T>
    {
        public string Description { get; set; }
        public OptionalType Type { get; set; }
        public OptionalItem<T>[] Items { get; set; }
        public T Selected { get; set; }

        public static SelectableOptionals<T> FromOptionals(Optional<T> optionals)
        {
            return new SelectableOptionals<T>()
            {
                Description = optionals.Description,
                Type = optionals.Type,
                Items = optionals.Items
            };
        }
    }
    
}
