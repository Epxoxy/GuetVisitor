﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GuetAnalysis
{
    public class ReceivedData<T>
    {
        public T WebData { get; private set; }
        public Exception Exception { get; set; }
        public string ErrorMsg { get; private set; }

        public static readonly ReceivedData<string> Empty = new ReceivedData<string>();
        public static ReceivedData<T> FromException(Exception ex)
        {
            return new ReceivedData<T>() { Exception = ex, ErrorMsg = ex.Message };
        }
        public static ReceivedData<T> FromWebData(T webData)
        {
            return new ReceivedData<T>() { WebData = webData };
        }

    }
}
